
public class max_comparator{
    public static void main(String[] args){
        System.out.println(max(10,15));
    }


public static int max(int x, int y){
    if (x > y){
        return x;
        }
    return y;
    }

}

